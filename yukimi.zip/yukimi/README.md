<p align="center">
<img src="https://f.top4top.io/p_1895sgjc40.png" alt="png" width="128" height="128"/>
</p>
<p align="center">
<a href="#"><img title="SELF BOT" src="https://img.shields.io/badge/SELF BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/MrG3P5"><img title="Author" src="https://img.shields.io/badge/Author-X MrG3P5-red.svg?style=for-the-badge&logo=github"></a>
</p>

## APIKEY & Author Packname sticker
Buka file config.json dan paste apikey di YOUR_APIKEY dan masukin nomer yang ingin dijadiin self
- [VHTEAR](https://api.vhtear.com)
- [Youtube-APIV3](https://www.youtube.com/watch?v=TE66McLMMEw)

### Installasi In TERMUX

```bash
> apt update && apt upgrade -y
> pkg install git -y
> pkg install bash -y
> git clone https://github.com/MrG3P5/SELF-BOT.git
> cd SELF-BOT
> bash install.sh
> npm start
```

| Sticker Creator |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Sticker WM                        |
|       ✅       | Sticker Trigger                   |
|       ✅       | Sticker wasted                   |

| Group |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Hidetag               |
|       ✅        |  Grup close atau open       |
|       ✅        |  Gcname          |
|       ✅        |  Gcdesk       |
|       ✅        |  Add              |
|       ✅        |  Kick              |
|       ✅        |  Ownergc              |
|       ✅        |  Leave              |
|       ✅        |  Promote              |
|       ✅        |  Demote              |

| MEDIA |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Ytstalk              |
|       ✅        |  Tomp3              |
|       ✅        |  Brainly              |
|       ✅        |  Truth              |
|       ✅        |  Dare              |
|       ✅        |  Play              |
|       ✅        |  Pinterest              |
|       ✅        |  Tahta              |
|       ✅        |  Ssweb              |
|       ✅        |  Igstalk              |
|       ✅        |  Playstore              |
|       ✅        |  Infoalamat              |
|       ✅        |  Puisiimg              |
|       ✅        |  Tiktok              |
|       ✅        |  Toimg              |

| STORAGE |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Addsticker             |
|       ✅        |  Getsticker             |
|       ✅        |  Delsticker             |
|       ✅        |  Stickerlist             |
|       ✅        |  Addvn             |
|       ✅        |  Getvn             |
|       ✅        |  Delvn             |
|       ✅        |  Listvn             |
|       ✅        |  Addvideo             |
|       ✅        |  Getvideo             |
|       ✅        |  Delvideo             |
|       ✅        |  Listvideo             |
|       ✅        |  Addimage             |
|       ✅        |  Getimage             |
|       ✅        |  Delimage             |
|       ✅        |  Listimage             |

| ADVANCE |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Upswteks        |
|       ✅        |  Upswimage        |
|       ✅        |  Upswvideo        |
|       ✅        |  Afk Group        |
|       ✅        |  Afk Chat        |
|       ✅        |  Setpp             |
|       ✅        |  Clearall             |
|       ✅        |  Readallchat             |
|       ✅        |  Fakedeface             |
|       ✅        |  Setthumb             |
|       ✅        |  Antidelete group             |
|       ✅        |  Antidelete kontak             |
|       ✅        |  Return             |
|       ✅        |  Cr1 (fake reply grup)             |
|       ✅        |  Cr2 (fake reply private)             |
|       ✅        |  Runtime             |
|       ✅        |  Settarget             |
|       ✅        |  Term             |
|       ✅        |  Ping             |
|       ✅        |  Setreply             |
|       ✅        |  Setnumber             |
|       ✅        |  Cekchat             |

| VOICE |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  Slowmo             |
|       ✅        |  Bass             |
|       ✅        |  Tupai             |
|       ✅        |  Toptt             |

| PENTEST |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |  findhost             |
|       ✅        |  dork             |
|       ✅        |  nmap             |


## 🙏 Special Thanks To
<ul>
<li>https://github.com/adiwajshing/Baileys<br>
<li>https://github.com/MhankBarBar<br>
</li>
